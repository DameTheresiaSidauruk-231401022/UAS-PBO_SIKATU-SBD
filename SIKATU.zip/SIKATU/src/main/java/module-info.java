// File: src/main/java/module-info.java (VERSI FINAL & BENAR)

module com.sikatu.bantu_teman {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires org.xerial.sqlitejdbc;
    requires org.kordamp.ikonli.javafx;

    // INI ADALAH PERBAIKANNYA.
    // Gunakan nama modul otomatis dari library jbcrypt.
    requires jbcrypt;

    // Buka package ke javafx.fxml agar bisa membaca FXML
    opens com.sikatu.bantu_teman to javafx.fxml;
    opens com.sikatu.bantu_teman.controller to javafx.fxml;
    opens com.sikatu.bantu_teman.model to javafx.base;

    // Export package utama
    exports com.sikatu.bantu_teman;
    exports com.sikatu.bantu_teman.controller;
    exports com.sikatu.bantu_teman.model;
}