// File: bantu_teman/src/main/java/com/sikatu/bantu_teman/model/Task.java

package com.sikatu.bantu_teman.model;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

// Kelas ini untuk menampung data sebuah task
public class Task {
    private final int id;
    private final StringProperty taskName;
    private final String description;
    private final String endTime; // Deadline
    private final int priority;
    private String status; // Diubah dari final

    public Task(int id, String taskName, String description, String endTime, int priority, String status) {
        this.id = id;
        this.taskName = new SimpleStringProperty(taskName);
        this.description = description;
        this.endTime = endTime;
        this.priority = priority;
        this.status = status;
    }

    // Getters
    public int getId() { return id; }
    public String getTaskName() { return taskName.get(); }
    public StringProperty taskNameProperty() { return taskName; }
    public String getDescription() { return description; }
    public String getEndTime() { return endTime; }
    public int getPriority() { return priority; }
    public String getStatus() { return status; }

    // --- TAMBAHAN BARU ---
    /**
     * Mengatur status baru untuk tugas.
     * @param status Status baru ('in_progress' atau 'completed').
     */
    public void setStatus(String status) {
        this.status = status;
    }
}