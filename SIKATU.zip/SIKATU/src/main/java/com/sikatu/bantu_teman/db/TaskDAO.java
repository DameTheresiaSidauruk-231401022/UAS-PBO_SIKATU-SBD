// File: bantu_teman/src/main/java/com/sikatu/bantu_teman/db/TaskDAO.java

package com.sikatu.bantu_teman.db;

import com.sikatu.bantu_teman.model.Task;

import java.sql.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class TaskDAO {

    public void createTask(int userId, String name, String description, String endTime, int priority) throws SQLException {
        String sql = "INSERT INTO tasks(user_id, task_name, description, end_time, priority, status) VALUES(?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseManager.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, userId);
            pstmt.setString(2, name);
            pstmt.setString(3, description);
            pstmt.setString(4, endTime);
            pstmt.setInt(5, priority);
            pstmt.setString(6, "in_progress");
            pstmt.executeUpdate();
        }
    }

    public void updateTaskStatus(int taskId, String newStatus) throws SQLException {
        String sql = "UPDATE tasks SET status = ? WHERE id = ?";
        try (Connection conn = DatabaseManager.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, newStatus);
            pstmt.setInt(2, taskId);
            pstmt.executeUpdate();
        }
    }

    // --- METODE BARU ---
    /**
     * Mengambil semua tugas yang belum selesai ('in_progress') milik seorang user.
     * @param userId ID user.
     * @return List objek Task yang belum selesai.
     * @throws SQLException jika query gagal.
     */
    public List<Task> getAllUnfinishedTasks(int userId) throws SQLException {
        List<Task> tasks = new ArrayList<>();
        String sql = "SELECT * FROM tasks WHERE user_id = ? AND status = 'in_progress' ORDER BY end_time ASC, priority ASC";
        try (Connection conn = DatabaseManager.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, userId);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                tasks.add(new Task(
                        rs.getInt("id"),
                        rs.getString("task_name"),
                        rs.getString("description"),
                        rs.getString("end_time"),
                        rs.getInt("priority"),
                        rs.getString("status")
                ));
            }
        }
        return tasks;
    }

    public int getTotalTaskCount(int userId) throws SQLException {
        String sql = "SELECT COUNT(*) FROM tasks WHERE user_id = ?";
        try (Connection conn = DatabaseManager.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, userId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1);
            }
        }
        return 0;
    }

    public int getTaskCountByStatus(int userId, String status) throws SQLException {
        String sql = "SELECT COUNT(*) FROM tasks WHERE user_id = ? AND status = ?";
        try (Connection conn = DatabaseManager.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, userId);
            pstmt.setString(2, status);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1);
            }
        }
        return 0;
    }

    public int getUrgentTaskCount(int userId) throws SQLException {
        String tomorrow = LocalDate.now().plusDays(1).format(DateTimeFormatter.ISO_LOCAL_DATE);
        String sql = "SELECT COUNT(*) FROM tasks WHERE user_id = ? AND status = 'in_progress' AND date(end_time) <= date(?)";
        try (Connection conn = DatabaseManager.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, userId);
            pstmt.setString(2, tomorrow);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1);
            }
        }
        return 0;
    }

    public List<Task> getTasksForToday(int userId) throws SQLException {
        return getTasksForDate(userId, LocalDate.now());
    }

    public List<Task> getTasksForDate(int userId, LocalDate date) throws SQLException {
        List<Task> tasks = new ArrayList<>();
        String dateString = date.format(DateTimeFormatter.ISO_LOCAL_DATE);
        String sql = "SELECT * FROM tasks WHERE user_id = ? AND date(end_time) = date(?) ORDER BY priority ASC, end_time ASC";
        try (Connection conn = DatabaseManager.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, userId);
            pstmt.setString(2, dateString);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                tasks.add(new Task(
                        rs.getInt("id"),
                        rs.getString("task_name"),
                        rs.getString("description"),
                        rs.getString("end_time"),
                        rs.getInt("priority"),
                        rs.getString("status")
                ));
            }
        }
        return tasks;
    }
}