package com.sikatu.bantu_teman;

import com.sikatu.bantu_teman.db.DatabaseManager;
import com.sikatu.bantu_teman.util.SceneManager;
import javafx.application.Application;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.SQLException;

public class MainApp extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        // Inisialisasi Database saat aplikasi dimulai
        try {
            DatabaseManager.initializeDatabase();
        } catch (SQLException e) {
            e.printStackTrace();
            // Tampilkan alert error ke user jika database gagal dibuat
            // ... (bisa ditambahkan nanti)
            return;
        }

        // Mengatur stage utama
        stage.setTitle("SIKATU Task Manager");
        stage.setResizable(false); // Ukuran window tidak bisa diubah

        // Menggunakan SceneManager untuk mengelola perpindahan scene
        SceneManager sceneManager = new SceneManager(stage);
        sceneManager.switchToSplashScreen(); // Mulai dari Splash Screen

        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}