// File: bantu_teman/src/main/java/com/sikatu/bantu_teman/db/UserDAO.java
// Tidak ada perubahan. Kode ini sudah benar.

package com.sikatu.bantu_teman.db;

import com.sikatu.bantu_teman.model.User;
import org.mindrot.jbcrypt.BCrypt;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

public class UserDAO {

    public void signUp(String name, String email, String password) throws SQLException {
        String hashedPassword = BCrypt.hashpw(password, BCrypt.gensalt());
        String sql = "INSERT INTO users(name, email, password_hash) VALUES(?, ?, ?)";

        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, name);
            pstmt.setString(2, email);
            pstmt.setString(3, hashedPassword);
            pstmt.executeUpdate();
        }
    }

    public boolean login(String email, String password) throws SQLException {
        String sql = "SELECT id, name, password_hash FROM users WHERE email = ?";
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, email);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                String storedHash = rs.getString("password_hash");
                if (BCrypt.checkpw(password, storedHash)) {
                    int id = rs.getInt("id");
                    String name = rs.getString("name");
                    User.login(id, name, email);
                    return true;
                }
            }
        }
        return false;
    }

    public Optional<Map<String, String>> getUserDetails(int userId) throws SQLException {
        String sql = "SELECT name, email, date_of_birth, country, profile_image_path FROM users WHERE id = ?";
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, userId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                Map<String, String> details = new HashMap<>();
                details.put("name", rs.getString("name"));
                details.put("email", rs.getString("email"));
                details.put("dob", rs.getString("date_of_birth"));
                details.put("country", rs.getString("country"));
                details.put("imagePath", rs.getString("profile_image_path"));
                return Optional.of(details);
            }
        }
        return Optional.empty();
    }

    public void updateProfile(int userId, String dob, String country, String imagePath) throws SQLException {
        String sql = "UPDATE users SET date_of_birth = ?, country = ?, profile_image_path = ? WHERE id = ?";
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, dob);
            pstmt.setString(2, country);
            pstmt.setString(3, imagePath);
            pstmt.setInt(4, userId);
            pstmt.executeUpdate();
        }
    }
}