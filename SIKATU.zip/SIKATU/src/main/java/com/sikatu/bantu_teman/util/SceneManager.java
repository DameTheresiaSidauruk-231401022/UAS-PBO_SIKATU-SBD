// File: bantu_teman/src/main/java/com/sikatu/bantu_teman/util/SceneManager.java

package com.sikatu.bantu_teman.util;

import com.sikatu.bantu_teman.MainApp;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Objects;

public class SceneManager {
    private final Stage stage;
    private final double width = 390;
    private final double height = 844;

    public SceneManager(Stage stage) {
        this.stage = stage;
    }

    private void loadScene(String fxmlFile) {
        try {
            Parent root = FXMLLoader.load(Objects.requireNonNull(MainApp.class.getResource("/fxml/" + fxmlFile)));
            Scene scene = new Scene(root, width, height);
            stage.setScene(scene);
        } catch (IOException | NullPointerException e) {
            System.err.println("Error loading FXML file: " + fxmlFile);
            e.printStackTrace();
        }
    }

    public void switchToSplashScreen() {
        loadScene("SplashScreen.fxml");
    }

    public void switchToLogin() {
        loadScene("Login.fxml");
    }

    public void switchToSignUp() {
        loadScene("SignUp.fxml");
    }

    public void switchToDashboard() {
        loadScene("Dashboard.fxml");
    }

    // --- METODE BARU ---
    public void switchToAllTasks() {
        loadScene("AllTasks.fxml");
    }

    public void switchToCreateTask() {
        loadScene("CreateTask.fxml");
    }


    public void switchToCalendar() {
        loadScene("Calendar.fxml");
    }

    public void switchToCourses() {
        loadScene("Courses.fxml");
    }

    public void switchToSettings() {
        loadScene("Settings.fxml");
    }

    public void switchToProfile() {
        loadScene("Profile.fxml");
    }
}