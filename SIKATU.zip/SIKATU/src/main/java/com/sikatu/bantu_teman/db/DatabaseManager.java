package com.sikatu.bantu_teman.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseManager {
    private static final String DB_URL = "jdbc:sqlite:sikatu_tasks.db";

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(DB_URL);
    }

    public static void initializeDatabase() throws SQLException {
        try (Connection conn = getConnection(); Statement stmt = conn.createStatement()) {
            // Tabel Users
            String createUserTable = "CREATE TABLE IF NOT EXISTS users (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "name TEXT NOT NULL," +
                    "email TEXT NOT NULL UNIQUE," +
                    "password_hash TEXT NOT NULL," +
                    "date_of_birth TEXT," +
                    "country TEXT," +
                    "profile_image_path TEXT" +
                    ");";
            stmt.execute(createUserTable);

            // Tabel Tasks
            String createTasksTable = "CREATE TABLE IF NOT EXISTS tasks (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "user_id INTEGER NOT NULL," +
                    "task_name TEXT NOT NULL," +
                    "description TEXT," +
                    "start_time TEXT," +
                    "end_time TEXT NOT NULL," + // Deadline
                    "priority INTEGER NOT NULL," + // 1-High, 2-Medium, 3-Low
                    "status TEXT NOT NULL," + // 'in_progress', 'completed'
                    "FOREIGN KEY(user_id) REFERENCES users(id)" +
                    ");";
            stmt.execute(createTasksTable);

            System.out.println("Database and tables initialized successfully.");
        }
    }
}