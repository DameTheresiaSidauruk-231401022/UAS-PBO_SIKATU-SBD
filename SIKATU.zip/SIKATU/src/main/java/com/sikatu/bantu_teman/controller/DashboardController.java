// File: bantu_teman/src/main/java/com/sikatu/bantu_teman/controller/DashboardController.java

package com.sikatu.bantu_teman.controller;

import com.sikatu.bantu_teman.db.TaskDAO;
import com.sikatu.bantu_teman.db.UserDAO;
import com.sikatu.bantu_teman.model.Task;
import com.sikatu.bantu_teman.model.User;
import com.sikatu.bantu_teman.util.SceneManager;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Circle;
import javafx.scene.text.Font;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Map;
import java.util.Optional;

public class DashboardController {

    @FXML private Label userNameLabel;
    @FXML private Circle profileImageCircle;
    @FXML private Label totalTaskLabel;
    @FXML private Label completeLabel;
    @FXML private Label inProgressLabel;
    @FXML private Label urgentLabel;
    @FXML private Label progressPercentageLabel;
    @FXML private ProgressBar overallProgressBar;
    @FXML private ListView<Task> todayTaskListView;
    @FXML private HBox seeAllButton;

    // --- PERUBAHAN TIPE DATA DI SINI ---
    @FXML private HBox homeButton;
    @FXML private HBox calendarButton;
    @FXML private HBox createTaskButton;
    @FXML private HBox coursesButton;
    @FXML private HBox settingsButton;

    private final TaskDAO taskDAO = new TaskDAO();
    private final UserDAO userDAO = new UserDAO();
    private User currentUser;

    @FXML
    public void initialize() {
        currentUser = User.getCurrentUser();
        if (currentUser == null) {
            System.err.println("CRITICAL: Dashboard accessed without a logged-in user.");
            return;
        }

        userNameLabel.setText(currentUser.getName());

        loadDashboardData(currentUser.getId());
        loadProfilePicture(currentUser.getId());
        setupTaskListView();
        setupNavigation();
    }

    private void loadProfilePicture(int userId) {
        try {
            Optional<Map<String, String>> userDetails = userDAO.getUserDetails(userId);
            userDetails.ifPresent(details -> {
                String imagePath = details.get("imagePath");
                if (imagePath != null && !imagePath.isEmpty()) {
                    File imgFile = new File(imagePath);
                    if (imgFile.exists()) {
                        Image image = new Image(imgFile.toURI().toString());
                        profileImageCircle.setFill(new ImagePattern(image));
                    }
                }
            });
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void loadDashboardData(int userId) {
        try {
            int totalTasks = taskDAO.getTotalTaskCount(userId);
            int completedTasks = taskDAO.getTaskCountByStatus(userId, "completed");
            int inProgressTasks = totalTasks - completedTasks;
            int urgentTasks = taskDAO.getUrgentTaskCount(userId);
            totalTaskLabel.setText(String.valueOf(totalTasks));
            completeLabel.setText(String.valueOf(completedTasks));
            inProgressLabel.setText(String.valueOf(inProgressTasks));
            urgentLabel.setText(String.valueOf(urgentTasks));
            double progress = (totalTasks == 0) ? 0.0 : (double) completedTasks / totalTasks;
            overallProgressBar.setProgress(progress);
            progressPercentageLabel.setText(String.format("%.0f%%", progress * 100));
            todayTaskListView.setItems(FXCollections.observableArrayList(taskDAO.getTasksForToday(userId)));
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void setupTaskListView() {
        todayTaskListView.setPlaceholder(new Label("No tasks for today. Great job!"));
        todayTaskListView.setCellFactory(param -> new ListCell<>() {
            @Override
            protected void updateItem(Task item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                    setGraphic(null);
                    setStyle("");
                } else {
                    HBox hbox = new HBox(10);
                    String backgroundColor = item.getStatus().equals("completed") ? "#A0C878" : "#FFEE93";
                    hbox.setStyle("-fx-background-color: " + backgroundColor + "; -fx-padding: 15; -fx-background-radius: 10; -fx-cursor: hand;");
                    Label taskName = new Label(item.getTaskName());
                    taskName.setFont(Font.font("System Bold", 16));
                    hbox.getChildren().add(taskName);
                    setGraphic(hbox);
                    setStyle("-fx-background-color: transparent; -fx-padding: 0 0 5 0;");
                    hbox.setOnMouseClicked(event -> {
                        if (item.getStatus().equals("in_progress")) {
                            showCompleteTaskDialog(item);
                        }
                    });
                }
            }
        });
    }

    private void showCompleteTaskDialog(Task task) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/CompleteTaskDialog.fxml"));
            Parent root = loader.load();
            CompleteTaskDialogController controller = loader.getController();
            controller.setTask(task);
            Stage dialogStage = new Stage();
            dialogStage.initStyle(StageStyle.TRANSPARENT);
            dialogStage.initModality(Modality.APPLICATION_MODAL);
            Scene scene = new Scene(root);
            scene.setFill(Color.TRANSPARENT);
            dialogStage.setScene(scene);
            Stage ownerStage = (Stage) todayTaskListView.getScene().getWindow();
            dialogStage.initOwner(ownerStage);
            dialogStage.showAndWait();
            if (controller.isConfirmed()) {
                taskDAO.updateTaskStatus(task.getId(), "completed");
                task.setStatus("completed");
                loadDashboardData(currentUser.getId());
                todayTaskListView.refresh();
            }
        } catch (IOException | SQLException e) {
            e.printStackTrace();
            Alert errorAlert = new Alert(Alert.AlertType.ERROR);
            errorAlert.setTitle("Error");
            errorAlert.setContentText("Could not process the task completion.");
            errorAlert.showAndWait();
        }
    }

    private void setupNavigation() {
        if (profileImageCircle != null)
            profileImageCircle.setOnMouseClicked(e -> navigateTo(profileImageCircle, new SceneManager((Stage) profileImageCircle.getScene().getWindow())::switchToProfile));
        if (calendarButton != null)
            calendarButton.setOnMouseClicked(e -> navigateTo(calendarButton, new SceneManager((Stage) calendarButton.getScene().getWindow())::switchToCalendar));
        if (coursesButton != null)
            coursesButton.setOnMouseClicked(e -> navigateTo(coursesButton, new SceneManager((Stage) coursesButton.getScene().getWindow())::switchToCourses));
        if (settingsButton != null)
            settingsButton.setOnMouseClicked(e -> navigateTo(settingsButton, new SceneManager((Stage) settingsButton.getScene().getWindow())::switchToSettings));
        if (createTaskButton != null)
            createTaskButton.setOnMouseClicked(e -> navigateTo(createTaskButton, new SceneManager((Stage) createTaskButton.getScene().getWindow())::switchToCreateTask));
        if (seeAllButton != null)
            seeAllButton.setOnMouseClicked(e -> navigateTo(seeAllButton, new SceneManager((Stage) seeAllButton.getScene().getWindow())::switchToAllTasks));
    }

    private void navigateTo(Node node, Runnable navigationMethod) {
        navigationMethod.run();
    }
}