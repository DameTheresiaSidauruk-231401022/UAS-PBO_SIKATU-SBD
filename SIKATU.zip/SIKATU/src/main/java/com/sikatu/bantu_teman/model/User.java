package com.sikatu.bantu_teman.model;

// Kelas ini untuk menyimpan data user yang sedang login
public class User {
    private int id;
    private String name;
    private String email;
    // tambahkan atribut lain jika perlu, misal dob, country

    // Singleton pattern untuk menyimpan user session
    private static User instance;

    private User(int id, String name, String email) {
        this.id = id;
        this.name = name;
        this.email = email;
    }

    public static void login(int id, String name, String email) {
        instance = new User(id, name, email);
    }

    public static void logout() {
        instance = null;
    }

    public static User getCurrentUser() {
        return instance;
    }

    // Getters
    public int getId() { return id; }
    public String getName() { return name; }
    public String getEmail() { return email; }
}